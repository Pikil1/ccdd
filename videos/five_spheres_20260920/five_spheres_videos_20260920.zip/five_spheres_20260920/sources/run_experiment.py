#!/usr/bin/env python3
"""Reproduce the two selected conditions with matched implicitfast integration."""
import concurrent.futures
import json
import os
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[1]
HISTORICAL = '--historical' in sys.argv
if HISTORICAL:
    ROOT = ROOT / 'historical_protocol'
    ROOT.mkdir(exist_ok=True)
sys.path.insert(0, str(PROJECT))
for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[name] = '1'
os.environ['MPLCONFIGDIR'] = '/tmp/five-spheres-video-mpl'
os.environ['LD_LIBRARY_PATH'] = '/home/roboticslab/miniconda3/envs/simple51/lib:' + os.environ.get('LD_LIBRARY_PATH', '')

import mujoco
import run_external_avoidance_comparison as bench


def main():
    command = json.loads((PROJECT / 'outputs/fasm_implicitfast_comparison_20260915/reference_arguments.json').read_text())
    for option, value in {'--algorithms': 'facbf_adaptive,fasm,neo,mppi,ds', '--speeds': '0.4,1.2',
                          '--noises': '0.006', '--output-root': str(ROOT), '--timeout': '1800'}.items():
        command[command.index(option) + 1] = value
    command.append('--resume')
    sys.argv = command[1:]
    args = bench.parse_args()
    args.canonical_model = ROOT / 'models/fr3_right_with_spheres.xml'
    args.canonical_model.parent.mkdir(parents=True, exist_ok=True)
    source = PROJECT / 'outputs/fasm_implicitfast_comparison_20260915/fr3_right_with_spheres_implicitfast.xml'
    if HISTORICAL:
        canonical_source = args.mppi_root / 'models/fr3_right_with_spheres.xml'
        canonical_tree = ET.parse(canonical_source)
        canonical_compiler = canonical_tree.getroot().find('compiler')
        canonical_compiler.set('meshdir', str((canonical_source.parent / canonical_compiler.get('meshdir', '')).resolve()))
        canonical_tree.write(args.canonical_model)
    else:
        args.canonical_model.write_bytes(source.read_bytes())
    ds_source = args.ds_root / 'models/fr3.xml'
    tree = ET.parse(ds_source)
    if not HISTORICAL:
        tree.getroot().find('option').set('integrator', 'implicitfast')
    compiler = tree.getroot().find('compiler')
    compiler.set('meshdir', str((ds_source.parent / compiler.get('meshdir', '')).resolve()))
    ds_model = ROOT / 'ds_runtime/models/fr3.xml'
    ds_model.parent.mkdir(parents=True, exist_ok=True)
    tree.write(ds_model)
    for path in (args.canonical_model, ds_model):
        model = mujoco.MjModel.from_xml_path(str(path))
        assert model.opt.integrator == (mujoco.mjtIntegrator.mjINT_EULER if HISTORICAL else mujoco.mjtIntegrator.mjINT_IMPLICITFAST)
        assert model.opt.timestep == .001
    original_command = bench.command_for_algorithm

    def command_for_algorithm(algorithm, **kwargs):
        cmd, cwd, overrides, codes = original_command(algorithm, **kwargs)
        if algorithm == 'mppi':
            overrides['MPPI_MUJOCO_MODEL_PATH'] = str(args.canonical_model)
        if algorithm == 'ds':
            cwd = ds_model.parents[1]
        if HISTORICAL and algorithm == 'fasm':
            overrides['FACBF_MUJOCO_MODEL_PATH'] = str(source)
        return cmd, cwd, overrides, codes

    bench.command_for_algorithm = command_for_algorithm
    bench.validate_inputs(args)
    manifest = bench.build_manifest(args)
    manifest.update(plant_integrator='implicitfast', physics_dt_s=.001,
                    purpose='Two selected video conditions; fresh simulations, not historical table replay',
                    ds_model=str(ds_model))
    if HISTORICAL:
        manifest.update(plant_integrator={'fasm':'implicitfast', 'others':'Euler'},
                        purpose='Fresh reproduction of historical comparison settings; integrators differ across methods')
    bench.write_json(ROOT / 'experiment_manifest.json', manifest)
    bench.write_json(ROOT / 'reference_arguments.json', command)
    tasks = []
    for speed in args.speeds:
        starts = bench.sphere_starts_for_condition(layout=args.sphere_layout, speed_mps=speed,
                    synchronize_crossing=args.sphere_sync_crossing, reference_speed_mps=args.sphere_reference_speed,
                    crossing_y_m=args.sphere_crossing_y)
        measurement, meta = bench.prepare_position_measurement_file(args, speed_mps=speed,
                    noise_std_m=.006, repeat=0, sphere_starts_m=starts)
        for algorithm in args.algorithms:
            tasks.append((algorithm, speed, starts, measurement))

    def run(task):
        algorithm, speed, starts, measurement = task
        print(f'START {algorithm} speed={speed}', flush=True)
        row = bench.run_one(algorithm, args=args, speed_mps=speed, noise_std_m=.006,
                    measurement_delay_s=0., measurement_path=measurement, repeat=0, sphere_starts_m=starts)
        valid = bool(row['process_ok'] and row['position_only_audit_passed'] and row.get('coverage_fraction', 0) >= .995)
        row['valid_complete'] = valid
        row['category'] = ('Q' if not valid else 'C' if not row['collision_free'] else
                           'G' if not row['goal_reached'] else 'S' if row['safety_passed'] else 'P')
        row['plant_integrator'] = 'Euler' if HISTORICAL and algorithm != 'fasm' else 'implicitfast'
        bench.write_json(Path(row['run_dir']) / 'result.json', row)
        print(f"DONE {algorithm} speed={speed} {row['category']} clearance={row.get('minimum_clearance_m')} "
              f"entry={row.get('goal_reached_time_s')} wall={row['wall_time_s']:.1f}s", flush=True)
        return row

    rows = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for future in concurrent.futures.as_completed([pool.submit(run, task) for task in tasks]):
            rows.append(future.result())
            bench.write_json(ROOT / 'results.json', sorted(rows, key=lambda r: (r['speed_mps'], r['algorithm'])))
    bench.write_results_csv(ROOT / 'results.csv', rows)
    assert len(rows) == 10 and all(row['valid_complete'] for row in rows), 'Incomplete run; inspect logs'
    print('ALL TEN RUNS COMPLETE', flush=True)


if __name__ == '__main__':
    main()
