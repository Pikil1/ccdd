#!/usr/bin/env python3
"""Validate both videos and assemble an auditable delivery ZIP and repo folder."""
import csv
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile
import imageio_ffmpeg

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'historical_protocol'
DELIVERY = ROOT / 'delivery'
REPO = Path('/tmp/ccdd-five-spheres-20260920')
PUBLISH = REPO / 'videos/five_spheres_20260920'
NAMES = {'facbf_adaptive':'RA-CBF', 'fasm':'FASM', 'neo':'NEO', 'mppi':'GPU MPPI', 'ds':'Dynamic DS'}
ORDER = list(NAMES)
KEYS = ['algorithm','speed_mps','position_noise_std_m','category','plant_integrator','valid_complete',
        'minimum_clearance_m','minimum_clearance_time_s','goal_reached_time_s','collision_free',
        'position_only_audit_passed','position_measurement_sha256','coverage_fraction']


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    rows = json.loads((ROOT / 'results.json').read_text())
    rows.sort(key=lambda r:(r['speed_mps'],ORDER.index(r['algorithm'])))
    assert len(rows)==10 and all(r['valid_complete'] and r['position_only_audit_passed'] for r in rows)
    assert [r['category'] for r in rows]==['S','S','S','C','P','S','C','S','S','S']
    compact = [{k:r[k] for k in KEYS} for r in rows]
    (DELIVERY / 'results.json').write_text(json.dumps(compact,indent=2)+'\n')
    with (DELIVERY / 'results.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=KEYS)
        writer.writeheader()
        writer.writerows(compact)
    videos = sorted(DELIVERY.glob('*.mp4'))
    assert len(videos)==2
    validation=[]
    for path, expected in zip(videos, [751,1112]):
        subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-v','error','-i',str(path),'-f','null','-'], check=True)
        count, seconds=imageio_ffmpeg.count_frames_and_secs(str(path))
        reader=imageio_ffmpeg.read_frames(str(path))
        meta=next(reader)
        reader.close()
        assert count==expected and meta['size']==(1920,1080) and meta['fps']==30
        validation.append(dict(file=path.name,sha256=digest(path),bytes=path.stat().st_size,
                               frames=count,duration_s=seconds,resolution=[1920,1080],fps=30,
                               codec=meta['codec'],full_decode_passed=True))
    diagnostic=json.loads((BASE/'results.json').read_text())
    diagnostic=[{k:r.get(k) for k in KEYS} for r in diagnostic]
    (DELIVERY/'unified_integrator_diagnostic.json').write_text(json.dumps(diagnostic,indent=2)+'\n')
    lines=[]
    for row in rows:
        lines.append(f"| {row['speed_mps']:.1f} | {NAMES[row['algorithm']]} | {row['category']} | {1000*row['minimum_clearance_m']:.3f} | {row['goal_reached_time_s']:.3f} |")
    readme='''# 五球体障碍物避障对比视频 / Five-sphere avoidance comparison

两组条件：障碍物速度 **0.4 m/s** 和 **1.2 m/s**；位置噪声标准差均为 **6 mm**。
五种算法：RA-CBF、FASM、NEO、GPU MPPI、Dynamic DS。

## 下载

- [下载完整 ZIP 压缩包](five_spheres_videos_20260920.zip)：视频、十条原始轨迹、观测流、结果、参数、制作脚本及校验记录。
- [0.4 m/s 对比视频](five_spheres_speed_0p4_noise_6mm.mp4)：1920×1080、30 fps、H.264，约 25 秒。
- [1.2 m/s 对比视频](five_spheres_speed_1p2_noise_6mm.mp4)：同规格，约 37 秒，附 0–3 秒仿真过程的 0.25 倍速重放。

每段均完整回放 0–20 秒仿真过程，另有结果停留画面。所有算法同步仿真时间、相同相机与倍率。
英文标签用于论文演示：Clearance 为当前精确网格间距，Min so far 为截至当前的累计最小间距。
碰撞标记一经出现即保留。红色空间标记表示当前最近点间距低于 20 mm；绿色点为目标；青色轨迹对应评分使用的 link-7。
画面帧间做关节插值；指标按原记录在 5 ms 网格评分，不从渲染图像估算。

## 本次实际重跑结果

这些是 2026-09-20 新运行结果，视频标签由新轨迹计算，没有直接套用历史表数值。
S：完整无碰撞到达且全程间距 ≥20 mm；P：完整无碰撞到达但间距低于 20 mm；C：曾发生网格碰撞。
首次到达时间仅表示曾进入 30 mm 目标区，发生碰撞的运行仍记为失败。

| 速度 (m/s) | 算法 | 结果 | 最小间距 (mm) | 首次到达 (s) |
|---|---|---|---|---|
'''+ '\n'.join(lines)+'''

## 实验版本与复现

本视频复现先前选档所依据的历史比较配置：**FASM 使用 implicitfast，其他四种算法使用 Euler**，物理步长均为 1 ms。
这项差异也直接标在视频底部。因此它用于展示该实验版本，不能当成统一积分器下的算法性能排名。
控制器保留各自既有控制周期、执行器和观测估计器。五种算法使用同一初始关节状态、五球固定 blend25 布局、同一位置观测文件、种子 20260822、零附加观测延迟；未为视频调参。
每档五种算法的观测流 SHA-256 一致，十次运行均完整并通过 position-only 输入审计。

制作前另跑过全方法 implicitfast 诊断：两档 RA-CBF 提前发生严格 QP 不可行退出，0.4 m/s 的 MPPI 无碰撞。
为保留原表配置对应的实验版本，主视频采用上面明确标注的历史设置；十次诊断的结果摘要保留在 `unified_integrator_diagnostic.json`，没有将其混入主视频。
即使保留原设置，部分间距与旧表仍有小幅数值差异；以本次原始记录及 `results.csv` 为准。

ZIP 中 `trajectories/` 保存十条原始记录；`measurements/` 保存两档共享观测流；`run_manifests/` 保存各方法实际命令及环境；`sources/` 保存制作脚本。
完整项目环境内运行 `run_experiment.py --historical`、`render_videos.py --historical` 可复现此流程；脚本依赖原 NEO_simulation 项目及其外部基线，不是独立仿真安装包。
视频经过完整解码、分辨率、帧率、帧数检查；详细数据见 `video_validation.json`。
'''
    (DELIVERY/'README.md').write_text(readme)
    (DELIVERY/'video_validation.json').write_text(json.dumps(validation,indent=2)+'\n')
    trajectory_dir=DELIVERY/'trajectories'
    manifest_dir=DELIVERY/'run_manifests'
    measurement_dir=DELIVERY/'measurements'
    source_dir=DELIVERY/'sources'
    for path in [trajectory_dir,manifest_dir,measurement_dir,source_dir]:
        path.mkdir(exist_ok=True)
    for row in rows:
        stem=f"speed_{row['speed_mps']:.1f}_{row['algorithm']}".replace('.','p')
        run=Path(row['run_dir'])
        shutil.copy2(run/'trajectory.csv',trajectory_dir/f'{stem}.csv')
        shutil.copy2(run/'run_manifest.json',manifest_dir/f'{stem}.json')
        measurement=Path(row['position_measurement_file'])
        assert digest(measurement)==row['position_measurement_sha256']
        shutil.copy2(measurement,measurement_dir/f"speed_{row['speed_mps']:.1f}.csv")
    for name in ['run_experiment.py','render_videos.py','package_delivery.py']:
        shutil.copy2(BASE/name,source_dir/name)
    for name in ['experiment_manifest.json','reference_arguments.json']:
        shutil.copy2(ROOT/name,DELIVERY/name)
    checksums={str(p.relative_to(DELIVERY)):digest(p) for p in sorted(DELIVERY.rglob('*')) if p.is_file() and p.suffix!='.zip' and p.name!='SHA256SUMS.json'}
    (DELIVERY/'SHA256SUMS.json').write_text(json.dumps(checksums,indent=2)+'\n')
    archive=ROOT/'five_spheres_videos_20260920.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for path in sorted(DELIVERY.rglob('*')):
            if path.is_file():
                z.write(path,Path('five_spheres_20260920')/path.relative_to(DELIVERY))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len([n for n in z.namelist() if n.endswith('.mp4')])==2
    assert archive.stat().st_size<95*1024*1024
    PUBLISH.mkdir(parents=True,exist_ok=True)
    shutil.copy2(archive,PUBLISH/archive.name)
    for path in DELIVERY.iterdir():
        if path.is_file() and path.suffix in ['.mp4','.md','.png','.json','.csv']:
            shutil.copy2(path,PUBLISH/path.name)
    print(json.dumps(dict(publish=str(PUBLISH),zip_bytes=archive.stat().st_size,
                          zip_sha256=digest(archive),videos=validation),indent=2))


if __name__=='__main__':
    main()
