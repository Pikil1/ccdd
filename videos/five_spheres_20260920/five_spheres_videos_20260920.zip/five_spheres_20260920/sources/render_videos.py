#!/usr/bin/env python3
"""Render synchronized, measured five-method replays, then encode H.264 MP4."""
import argparse
import csv
import json
import os
from pathlib import Path
import sys

os.environ.setdefault('MUJOCO_GL', 'egl')
os.environ.setdefault('MPLCONFIGDIR', '/tmp/five-spheres-video-mpl')
ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[1]
if '--historical' in sys.argv:
    ROOT = ROOT / 'historical_protocol'
sys.path.insert(0, str(PROJECT))
import imageio.v2 as imageio
import mujoco
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import run_external_avoidance_comparison as bench
from render_trajectory_frame import load_render_model, SPHERE_RGBA
from render_avoidance_stages import configure_studio, MotionRenderer
from replay_trajectory import resolve_model_indices

ORDER = ['facbf_adaptive', 'fasm', 'neo', 'mppi', 'ds']
NAMES = ['RA-CBF', 'FASM', 'NEO', 'GPU MPPI', 'Dynamic DS']
COLORS = ['#087f8c', '#8054b3', '#2577c0', '#dd7524', '#616d80']
INK, MUTED, BG = '#172333', '#536174', '#edf1f5'
GREEN, RED, AMBER = '#14734d', '#c92c3b', '#b87808'
OUT = ROOT / 'delivery'
OUT.mkdir(exist_ok=True)


def font(size, bold=False):
    return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans' + ('-Bold' if bold else '') + '.ttf', size)


def analyze(row):
    """Match the benchmark's exact mesh evaluator at its native 5 ms grid."""
    cache = Path(row['run_dir']) / 'video_metrics.npz'
    if cache.exists():
        return dict(np.load(cache))
    trajectory = bench.prepend_initial_state(bench.read_trajectory(Path(row['run_dir']) / 'trajectory.csv'),
                                             row['speed_mps'], sphere_starts_m=np.array(row['sphere_starts_m']))
    t = np.arange(0., min(20., trajectory['time'][-1]) + .0025, .005)
    t = t[t <= min(20., trajectory['time'][-1]) + 1e-12]
    q = np.column_stack([np.interp(t, trajectory['time'], trajectory['q'][:, j]) for j in range(7)])
    spheres = bench.expected_sphere_centers(t, row['speed_mps'], sphere_starts_m=np.array(row['sphere_starts_m']))
    model = mujoco.MjModel.from_xml_path(str(ROOT / 'models/fr3_right_with_spheres.xml'))
    data = mujoco.MjData(model)
    robot = [i for i in range(model.ngeom) if (model.geom(i).name or '').startswith('fr3_link') and 'collision' in model.geom(i).name]
    obstacles = [model.geom(f'sphere{i}_geom').id for i in range(5)]
    qadr, mocap = resolve_model_indices(model)
    ee = model.body('fr3_link7_right').id
    clearance, xyz = np.empty(len(t)), np.empty((len(t), 3))
    nearest = np.empty((len(t), 6))
    buf = np.zeros(6)
    for k in range(len(t)):
        data.qpos[qadr] = q[k]
        data.mocap_pos[mocap] = spheres[k]
        mujoco.mj_forward(model, data)
        minimum = np.inf
        for g in robot:
            for s in obstacles:
                value = mujoco.mj_geomDistance(model, data, g, s, 10., buf)
                if value < minimum:
                    minimum = value
                    nearest[k] = buf
        clearance[k] = minimum
        xyz[k] = data.xpos[ee]
    assert abs(clearance.min() - row['minimum_clearance_m']) < 1e-7, (row['algorithm'], clearance.min(), row['minimum_clearance_m'])
    result = dict(t=t, q=q, spheres=spheres, clearance=clearance, xyz=xyz, nearest=nearest,
                  minimum=np.minimum.accumulate(clearance), error=np.linalg.norm(xyz - bench.GOAL, axis=1))
    np.savez_compressed(cache, **result)
    return result


class Video:
    def __init__(self, rows):
        self.rows = sorted(rows, key=lambda r: ORDER.index(r['algorithm']))
        assert len(self.rows) == 5
        assert len({r['position_measurement_sha256'] for r in self.rows}) == 1
        self.metrics = [analyze(r) for r in self.rows]
        self.model = load_render_model(PROJECT / 'fr3_right_with_spheres_visual.xml', True)
        configure_studio(self.model)
        for i in range(5):
            self.model.geom_rgba[self.model.geom(f'sphere{i}_geom').id] = SPHERE_RGBA[i]
        self.qadr, self.mocap = resolve_model_indices(self.model)
        self.data = mujoco.MjData(self.model)
        self.camera = mujoco.MjvCamera()
        mujoco.mjv_defaultCamera(self.camera)
        self.camera.lookat[:] = (.22, -.14, .43)
        self.camera.azimuth = 150
        self.camera.elevation = -24
        self.camera.distance = 2.0
        self.renderer = mujoco.Renderer(self.model, height=366, width=620)
        self.renderer.scene.flags[mujoco.mjtRndFlag.mjRND_SHADOW] = False
        self.speed = self.rows[0]['speed_mps']

    def scene(self, metric, t):
        t = min(t, float(metric['t'][-1]))
        k = min(int(round(t / .005)), len(metric['t'])-1)
        # Interpolate on the common scoring grid; all panels share simulation time.
        q = np.array([np.interp(t, metric['t'], metric['q'][:, j]) for j in range(7)])
        self.data.qpos[self.qadr] = q
        self.data.mocap_pos[self.mocap] = np.array(self.rows[0]['sphere_starts_m']) + np.array([0., self.speed * t, 0.])
        mujoco.mj_forward(self.model, self.data)
        self.renderer.update_scene(self.data, camera=self.camera)
        scene = self.renderer.scene
        path = metric['xyz'][:k+1:12]
        for a, b in zip(path[:-1], path[1:]):
            MotionRenderer.connector(scene, a, b, .0022)
        geom = scene.geoms[scene.ngeom]
        mujoco.mjv_initGeom(geom, mujoco.mjtGeom.mjGEOM_SPHERE, np.array([.015, 0., 0.]),
                           bench.GOAL, np.eye(3).ravel(), np.array([.05, .65, .45, 1.]))
        scene.ngeom += 1
        if metric['clearance'][k] < .02:
            geom = scene.geoms[scene.ngeom]
            mujoco.mjv_initGeom(geom, mujoco.mjtGeom.mjGEOM_SPHERE, np.array([.025, 0., 0.]),
                               metric['nearest'][k].reshape(2, 3).mean(axis=0), np.eye(3).ravel(),
                               np.array([.95, .1, .12, .7]))
            scene.ngeom += 1
        return Image.fromarray(self.renderer.render()), k

    def frame(self, t, phase='REAL TIME  1x'):
        canvas = Image.new('RGB', (1920, 1080), BG)
        d = ImageDraw.Draw(canvas)
        d.text((24, 12), 'FIVE-SPHERE AVOIDANCE  |  ' + f'{self.speed:.1f} m/s', font=font(29, True), fill=INK)
        d.text((25, 51), 'Position noise: 6 mm (std)   |   Same initial state and observations   |   Safety threshold: 20 mm', font=font(20), fill=MUTED)
        d.text((1420, 15), phase, font=font(22, True), fill=INK)
        d.text((1680, 49), f't = {t:05.2f} s', font=font(23, True), fill=INK)
        for i, (name, metric) in enumerate(zip(NAMES, self.metrics)):
            x, y = (i % 3) * 640, 88 + (i // 3) * 474
            d.rounded_rectangle((x+8, y+4, x+632, y+468), radius=10, fill='white')
            d.rectangle((x+10, y+8, x+15, y+40), fill=COLORS[i])
            d.text((x+25, y+8), name, font=font(25, True), fill=INK)
            scene, k = self.scene(metric, t)
            canvas.paste(scene, (x+10, y+43))
            minimum = float(metric['minimum'][k])
            color = RED if minimum <= 0 else AMBER if minimum < .02 else GREEN
            collided = minimum <= 0
            entered = np.any(metric['error'][:k+1] <= .03)
            state = 'COLLISION' if collided else 'BELOW 20 mm' if minimum < .02 else 'CLEAR'
            if phase == 'FINAL RESULT':
                state = {'S':'SAFE SUCCESS', 'P':'SUCCESS / <20 mm', 'C':'COLLISION', 'G':'GOAL NOT REACHED', 'Q':'INCOMPLETE / QP EXIT'}[self.rows[i]['category']]
            if not self.rows[i]['valid_complete'] and t >= metric['t'][-1]:
                state = f'QP EXIT at {metric["t"][-1]:.3f}s / HELD'
                color = RED
            gap = float(metric['clearance'][k])
            gap_text = '>= 10 m' if gap >= 10.-1e-8 else f'{1000*gap:.1f} mm'
            d.text((x+25, y+411), f'Clearance: {gap_text}', font=font(19), fill=INK)
            d.text((x+340, y+411), f'Min so far: {1000*minimum:.1f} mm', font=font(19, True), fill=color)
            d.text((x+25, y+440), state, font=font(18, True), fill=color)
            d.text((x+355, y+440), 'Goal entered' if entered else 'Approaching goal', font=font(18), fill=MUTED)
        self.chart(d, t)
        note = 'Historical settings: FASM implicitfast; others Euler.' if '--historical' in sys.argv else 'Matched implicitfast integration, 1 ms physics.'
        d.text((24, 1046), 'Teal: link-7 path   Green: goal   Red: gap <20 mm  |  ' + note, font=font(18), fill=MUTED)
        return np.asarray(canvas)

    def chart(self, d, t):
        x, y = 1288, 566
        d.rounded_rectangle((x, y, x+624, y+464), radius=10, fill='white')
        d.text((x+20, y+12), 'Minimum clearance so far', font=font(25, True), fill=INK)
        d.text((x+20, y+49), 'Exact mesh distance, evaluated every 5 ms', font=font(17), fill=MUTED)
        left, top, width, height = x+64, y+95, 530, 205
        lo, hi = -30., 200.
        def point(time, value):
            return (left + time/20*width, top + (hi-np.clip(value, lo, hi))/(hi-lo)*height)
        for value in [-20, 0, 20, 100, 200]:
            yy = point(0, value)[1]
            d.line((left, yy, left+width, yy), fill='#d9e0e7' if value != 20 else AMBER, width=1)
            d.text((left-45, yy-9), str(value), font=font(14), fill=MUTED)
        for time in [0, 5, 10, 15, 20]:
            xx = point(time, 0)[0]
            d.text((xx-5, top+height+7), str(time), font=font(14), fill=MUTED)
        d.text((left+width-25, top+height+28), 's', font=font(15), fill=MUTED)
        d.text((left-45, top-24), 'mm', font=font(15), fill=MUTED)
        for metric, color in zip(self.metrics, COLORS):
            k = min(int(round(t/.005)), len(metric['t'])-1)
            indices = np.unique(np.r_[np.arange(0, k+1, 8), k])
            points = [point(metric['t'][j], 1000*metric['minimum'][j]) for j in indices]
            if len(points) > 1:
                d.line(points, fill=color, width=3)
        for i, (name, color) in enumerate(zip(NAMES, COLORS)):
            xx, yy = x+22+(i%3)*200, y+351+(i//3)*34
            d.rectangle((xx, yy+5, xx+18, yy+10), fill=color)
            d.text((xx+26, yy), name, font=font(16), fill=INK)
        d.text((x+22, y+430), 'All panels use the same camera and playback speed.', font=font(16), fill=MUTED)

    def render(self, preview=False):
        tag = f'speed_{self.speed:.1f}'.replace('.', 'p') + '_noise_6mm'
        Image.fromarray(self.frame(.8)).save(OUT / f'{tag}_preview.png')
        if preview:
            self.renderer.close()
            return
        path = OUT / f'five_spheres_{tag}.mp4'
        timeline = [(i/30., 'REAL TIME  1x') for i in range(601)]
        timeline.extend([(20., 'FINAL RESULT')] * 90)
        if self.speed > 1.:
            timeline.extend([(i/120., 'SLOW REPLAY  0.25x') for i in range(361)])
        timeline.extend([(20., 'FINAL RESULT')] * 60)
        writer = imageio.get_writer(path, fps=30, codec='libx264', pixelformat='yuv420p', macro_block_size=1,
                                    ffmpeg_params=['-crf', '23', '-preset', 'medium', '-movflags', '+faststart'])
        try:
            previous, frame = None, None
            for n, item in enumerate(timeline):
                if item != previous:
                    frame = self.frame(*item)
                    previous = item
                writer.append_data(frame)
                if n % 150 == 0:
                    print(f'RENDER {tag}: {n}/{len(timeline)} frames', flush=True)
        finally:
            writer.close()
            self.renderer.close()
        print(f'VIDEO {path} frames={len(timeline)}', flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--preview', action='store_true')
    parser.add_argument('--speed', type=float)
    parser.add_argument('--historical', action='store_true')
    args = parser.parse_args()
    rows = json.loads((ROOT / 'results.json').read_text())
    for speed in ([args.speed] if args.speed else [.4, 1.2]):
        Video([r for r in rows if r['speed_mps'] == speed]).render(args.preview)


if __name__ == '__main__':
    main()
